import React, { Component } from "react";
import Header from "../components/Header/Header";
import RecommendedVideos from "../components/RecommendedVideos/RecommendedVideos";
import Content from "../components/Content/Content";
import Forum from "../components/Forum/Forum";
import axios from "axios";

const API_URL =
  "https://project-2-api.herokuapp.com/videos?api_key=4647dc9f-39c6-41bf-a778-3df80b284b52";

export default class Home extends Component {
  state = {
    heroVid: {},
    recommVids: [],
    isLoading: true,
  };

  componentDidMount() {
    axios
      .get(API_URL)
      .then((res) => {
        // console.log(res.data, "componentDidMount");
        this.setState({ recommVids: res.data });
      })
      .catch();
  }
  handleLike = (id) => {
    axios.put(
      `https://project-2-api.herokuapp.com/videos/${id}?api_key=4647dc9f-39c6-41bf-a778-3df80b284b52`
    );
  };

  componentDidUpdate(prevProps, prevState) {
    console.log(prevProps.match.params.id, "prev props");
    console.log(prevState, "prev state");
    console.log(this.props.match.params.id, "current props");
    if (prevState.recommVids !== this.state.recommVids) {
      axios
        .get(API_URL)
        .then((res) => {
          const filteredArray = res.data.results.filter((recommVids) => {
            return recommVids.id !== this.state.recommVids.id;
          });
          this.setState({ recommVids: filteredArray });
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }

  // this.setState({
  //   heroVid: currentVid,
  // recommVids:
  // [].filter((video) => currentVid.id !== video.id),
  // });
  // };

  render() {
    // console.log(this.state.recommVids);
    return (
      this.state.recommVids && (
        <div>
          <Header />
          <Content heroVid={this.state.heroVid} />
          <Forum forumComments={this.state.heroVid} />
          <RecommendedVideos recommVids={this.state.recommVids} />
        </div>
      )
    );
  }
}
